# FiloPro Mobil (Capacitor + Arka Plan Konum) — Kurulum Rehberi

Bu klasör, mevcut FiloPro web uygulamanızı (`www/index.html`, `www/app.js`,
`www/sw.js`) değiştirmeden, üzerine gerçek bir Android/iOS uygulaması
kabuğu (Capacitor) giydirir. Tek eklenen şey: **arka planda / ekran kilitliyken
de çalışan native konum takibi** (`@capacitor-community/background-geolocation`).

`www/app.js`, sizin mevcut `app.js` dosyanızın üzerine şu üç küçük değişiklik
yapılmış hâlidir (aşağıda "Neyi Değiştirdik" bölümünde ayrıntılı anlatılıyor):
konum paylaşımı artık sayfa değiştirince durmuyor, ve **native ortamda
çalışıyorsa** otomatik olarak tarayıcı `watchPosition` yerine bu native
köprüyü kullanıyor. Web'de (bu klasörü hiç kullanmadan, sadece kendi sunucunuzda
barındırdığınız normal web sitesi olarak) hiçbir şey değişmez, aynen eskisi
gibi tarayıcı içi takip çalışmaya devam eder.

## 0) Gereksinimler

- Node.js 18+
- Android için: Android Studio (Giraffe veya üzeri)
- iOS için: Xcode 15+ ve bir Mac (Apple'ın kısıtı — Windows/Linux'ta iOS
  derlenemez)
- Gerçek bir telefon (arka plan konum testleri emülatör/simülatörde güvenilir
  çalışmaz)

## 1) Bağımlılıkları kurun

Bu klasörün içinde (bu `package.json`'ın bulunduğu yerde):

```bash
npm install
```

## 2) Native köprüyü derleyin

`src/native-konum-bridge.js` kaynak dosyasını, tarayıcının doğrudan
çalıştırabileceği tek bir dosyaya (`www/capacitor-konum-bridge.js`) paketler:

```bash
npm run build:bridge
```

Bu komutu, `src/native-konum-bridge.js` dosyasında değişiklik yaptığınız her
seferde tekrar çalıştırmanız gerekir (veya aşağıdaki `npm run android` /
`npm run ios` komutlarını kullanın, onlar zaten önce bunu çalıştırır).

## 3) Native projeleri oluşturun

```bash
npx cap add android
npx cap add ios      # sadece Mac'te
```

Bu, `android/` ve `ios/` klasörlerini oluşturur (gerçek Android Studio / Xcode
projeleridir, buradan sonra o projeleri normal native proje gibi
düzenleyebilirsiniz).

## 4) İzin/manifest eklemelerini yapın

- Android: `android-manifest-eklemeleri.md` dosyasındaki adımları uygulayın.
- iOS: `ios-info-plist-eklemeleri.md` dosyasındaki adımları uygulayın.

## 5) Senkronize edip açın

```bash
npm run android   # www/ içeriğini + bridge'i android projesine kopyalar, Android Studio'yu açar
npm run ios       # aynısı iOS için (sadece Mac)
```

Android Studio / Xcode açıldıktan sonra gerçek cihazınızı bağlayıp ▶ Run
diyerek kurun.

## 6) Web sitenizi de güncellemek isterseniz

`www/app.js`, sizin normal web sunucunuzda (`server.js`'in yanındaki statik
dosyalar) yayınladığınız `app.js` ile birebir uyumludur — isterseniz aynı
dosyayı web sitenize de kopyalayabilirsiniz; native köprü kodu sadece
`window.Capacitor` varsa devreye girdiği için web'de hiçbir şeyi bozmaz.

---

## Neyi Değiştirdik? (`app.js` içinde)

1. **`fpKonumBaslat(tip,id)`** artık en başta şunu kontrol ediyor:
   `window.Capacitor?.isNativePlatform()` doğruysa ve `window.FPNativeKonum`
   varsa (yani native köprü yüklüyse), tarayıcı `watchPosition` yerine
   `window.FPNativeKonum.baslat(...)` çağrılıyor — bu da native tarafta
   `@capacitor-community/background-geolocation`'ı devreye sokuyor.
2. Her iki yolda da (native veya tarayıcı) yeni bir konum geldiğinde artık
   45 saniyelik periyodik senkronu beklemeden **anında** `fpSyncNow()`
   çağrılıyor — böylece admin/diğer kullanıcılar konumu neredeyse gerçek
   zamanlı görür.
3. **`fpKonumDurdur()`** artık native köprü varsa onu da (`window.FPNativeKonum.durdur()`)
   durduruyor.

Konum paylaşımını sayfa değiştirince kesen eski sorun için yapılan düzeltme
(paylaşımın sayfadan bağımsız, global çalışması) zaten bu dosyada mevcut;
bu Capacitor entegrasyonu onun üzerine ekleme yapıyor.

## Gerçekçi Sınırlar (mutlaka okuyun)

- **Uygulama tamamen kapatılırsa/öldürülürse** (kullanıcı görev
  yöneticisinden kaydırarak kapatırsa), hiçbir platformda hiçbir teknoloji
  (bu dahil) konum göndermeye devam edemez. Foreground service (Android) bu
  ihtimali ciddi şekilde azaltır ama OS'un kendisi bazı üreticilerde
  (Xiaomi/Huawei gibi agresif pil optimizasyonu yapan cihazlarda) servisi
  yine de öldürebilir — kullanıcıların o cihazlarda "pil optimizasyonundan
  muaf tut" ayarını FiloPro için açması gerekebilir.
- **iOS**, Android'e göre çok daha kısıtlıdır; "Her Zaman İzin Ver" izni
  alınmadan arka plan takibi hiç çalışmaz (bkz. `ios-info-plist-eklemeleri.md`).
- Konum verisi cihazda üretildikten sonra sunucuya **internet varsa** anında,
  yoksa bağlantı gelince gönderilir (mevcut senkron mimariniz zaten böyle
  çalışıyor — WebSocket sadece "değişiklik var" bildirimi taşır, veri her
  zaman normal `fetch` ile gider).
