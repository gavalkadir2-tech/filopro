# iOS — `ios/App/App/Info.plist` içine eklenecekler

`npx cap add ios` komutundan sonra oluşan `ios/App/App/Info.plist` dosyasını
Xcode'da (veya bir metin editörüyle) açıp aşağıdaki anahtarları ekleyin.

## 1) Konum izni açıklama metinleri (zorunlu — yoksa Apple App Store reddeder)

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>FiloPro, saha ekibinin konumunu haritada göstermek için konumunuzu kullanır.</string>

<key>NSLocationAlwaysAndWhenInUseUsageDescription</key>
<string>FiloPro, konum paylaşımını açtığınızda uygulama arka plandayken de ekibinizin sizi haritada görebilmesi için konumunuzu kullanmaya devam eder.</string>

<key>NSLocationAlwaysUsageDescription</key>
<string>FiloPro, konum paylaşımını açtığınızda uygulama arka plandayken de ekibinizin sizi haritada görebilmesi için konumunuzu kullanmaya devam eder.</string>
```

## 2) Arka plan modu

```xml
<key>UIBackgroundModes</key>
<array>
  <string>location</string>
</array>
```

## Önemli — iOS'un kendi sınırları

- Kullanıcı ilk açılışta "Uygulamayı Kullanırken İzin Ver" seçerse arka plan
  takibi çalışmaz; "Her Zaman İzin Ver" (Always) seçmesi gerekir. Eklenti
  bunu otomatik istese de, iOS bazen önce "Kullanırken", birkaç gün sonra
  ayrıca "Her Zaman"ı sorar — kullanıcıya bunu Ayarlar'dan manuel açmasını
  anlatan bir bilgi metni eklemenizi öneririm (uygulama içinde zaten `hata`
  mesajıyla bunu söylüyoruz).
- iOS, uygulama tamamen sonlandırılıp (kullanıcı görev yöneticisinden kapatırsa)
  konum güncellemesi göndermeye genelde devam ETMEZ — sadece arka plana
  alınmış/kilitli ekran durumunda çalışır. Bu Apple'ın platform kısıtıdır,
  hiçbir üçüncü parti eklenti bunu aşamaz.
- Apple App Store incelemesi, "Always" konum izni isteyen uygulamalarda neden
  gerektiğini ayrıntılı açıklamanızı isteyebilir (App Store Connect'teki
  "App Privacy" ve inceleme notları bölümüne saha ekibi takibi olduğunu yazın).

## Test

```bash
npm run ios
```
Xcode açılınca gerçek bir iPhone'a (simülatörde arka plan konum testi
güvenilir değildir) bağlanıp ▶ Run ile kurun.
