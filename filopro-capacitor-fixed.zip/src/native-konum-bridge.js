// FiloPro — Native Arka Plan Konum Köprüsü
// ------------------------------------------------------------------------------
// Bu dosya SADECE Capacitor'ın native kabuğu (Android/iOS) içinde çalıştığında
// anlamlıdır. Düz web sitesi olarak açıldığında (window.Capacitor tanımsız
// olduğu için) app.js bu köprüyü hiç kullanmaz, tarayıcı içi eski davranışa
// (navigator.geolocation.watchPosition) otomatik döner.
//
// ÖNEMLİ: Bu dosya artık esbuild ile PAKETLENMİYOR. @capacitor-community/
// background-geolocation gibi native eklentiler, Capacitor'ın native kabuğu
// tarafından uygulama açılışında otomatik olarak window.Capacitor.Plugins
// altına kaydedilir. Bu eklentiyi npm paketinden import edip esbuild ile ayrı
// bir dosyaya paketlemeye çalışmak, @capacitor/core'un İKİNCİ bir kopyasını da
// pakete dahil ediyor ve bu kopya, sayfada zaten yüklü olan native köprüdeki
// Capacitor örneğinden FARKLI oluyordu — eklenti bu yüzden kayıt olamıyor ve
// esbuild da paketin "exports" yapısını çözemediği için derleme hatası
// veriyordu. Çözüm: paketlemeden, doğrudan window.Capacitor.Plugins üzerinden
// eklentiye erişmek (Capacitor'ın "no-bundler" / vanilla JS kullanım şekli).
//
// Bu dosya artık doğrudan www/ içinde durur, derlenmesine gerek yoktur ve
// index.html içine (SADECE native derlemede) doğrudan dahil edilir.

(function () {
  function getPlugin() {
    return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.BackgroundGeolocation;
  }

  let _watcherId = null;

  /**
   * Arka plan konum takibini başlatır.
   * @param {string} tip - "personel" | "arac"
   * @param {string|number} id - takip edilen kişi/aracın id'si
   * @param {(loc: {latitude:number,longitude:number,accuracy?:number,speed?:number}|null, hata?: string) => void} onKonum
   */
  async function baslat(tip, id, onKonum) {
    if (_watcherId != null) return; // zaten çalışıyor

    const BackgroundGeolocation = getPlugin();
    if (!BackgroundGeolocation) {
      onKonum(null, 'Native konum eklentisi bulunamadı (BackgroundGeolocation kaydı yok).');
      return;
    }

    try {
      _watcherId = await BackgroundGeolocation.addWatcher(
        {
          backgroundTitle: 'FiloPro Canlı Konum',
          backgroundMessage: 'Konum paylaşımı aktif — durdurmak için uygulamayı açıp "Paylaşımı Durdur"a basın.',
          requestPermissions: true,
          stale: false,
          // Konum en az bu kadar metre değiştiğinde güncelleme gelir (pil tasarrufu).
          distanceFilter: 15,
        },
        function (location, error) {
          if (error) {
            if (error.code === 'NOT_AUTHORIZED') {
              onKonum(null, 'Konum izni verilmedi. Telefon Ayarları > Uygulamalar > FiloPro > İzinler bölümünden konum iznini "Her zaman izin ver" olarak açın, ardından uygulamaya dönüp tekrar deneyin.');
              // Kullanıcıyı doğrudan ilgili ayar sayfasına da yönlendirebiliriz:
              // BackgroundGeolocation.openSettings();
            } else {
              onKonum(null, (error && error.message) || 'Konum alınamadı (native).');
            }
            return;
          }
          if (!location) return;
          onKonum(
            {
              latitude: location.latitude,
              longitude: location.longitude,
              accuracy: location.accuracy,
              speed: location.speed,
            },
            null
          );
        }
      );
    } catch (e) {
      onKonum(null, (e && e.message) || 'Arka plan konum servisi başlatılamadı.');
    }
  }

  async function durdur() {
    const BackgroundGeolocation = getPlugin();
    if (_watcherId != null && BackgroundGeolocation) {
      try {
        await BackgroundGeolocation.removeWatcher({ id: _watcherId });
      } catch (e) {
        // yoksay — zaten durdurulmuş olabilir
      }
      _watcherId = null;
    } else {
      _watcherId = null;
    }
  }

  function aktifMi() {
    return _watcherId != null;
  }

  // app.js'in kullandığı global köprü. app.js sadece
  // window.Capacitor?.isNativePlatform() true ise bunu kullanır.
  window.FPNativeKonum = { baslat, durdur, aktifMi };
})();
