# Android — `android/app/src/main/AndroidManifest.xml` içine eklenecekler

`npx cap add android` komutundan sonra oluşan `android/` klasörü içinde
`app/src/main/AndroidManifest.xml` dosyasını açın.

## 1) İzinler (`<manifest>` etiketinin içine, `<application>`'dan ÖNCE)

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

> `FOREGROUND_SERVICE_LOCATION`, Android 14 (API 34) hedefleniyorsa zorunludur.
> `POST_NOTIFICATIONS`, Android 13+ için kalıcı bildirimi göstermek üzere gereklidir.

## 2) Bildirim simgesi (foreground service için zorunlu)

`@capacitor-community/background-geolocation`, arka planda çalışırken bir
bildirim göstermek zorundadır (Android'in kuralı budur — kullanıcı arka planda
konumunun takip edildiğini her zaman görebilmelidir). Basit bir simge ekleyin:

`android/app/src/main/res/drawable/ic_stat_konum.xml` (basit bir nokta/pin ikonu,
Android Studio'nun "New > Image Asset > Notification Icon" sihirbazıyla da
üretebilirsiniz).

Eklentinin varsayılan simgesi yoksa uygulama derlenirken hata verebilir; bu
durumda eklenti dokümantasyonundaki `notificationIcon` yapılandırmasına da
bakın (bkz. `capacitor.config.json` içindeki `plugins.BackgroundGeolocation`).

## 3) minSdkVersion

`android/variables.gradle` içinde `minSdkVersion`'ın en az 23 olduğundan emin
olun (Capacitor'ın kendi varsayılanı zaten genelde uygundur).

## Test

```bash
npm run android
```
Android Studio açılınca gerçek bir cihaza (emülatörde arka plan konum testi
güvenilir değildir) USB ile bağlanıp ▶ Run ile kurun. Uygulamayı açıp Konum
sayfasından paylaşımı başlatın, ekranı kilitleyip birkaç dakika bekleyin,
ardından "FiloPro Canlı Konum" bildirimine dokunup uygulamaya dönün — konum
akmaya devam etmiş olmalı.
